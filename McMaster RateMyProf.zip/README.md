# McMaster_RMP
IN PROGRESS - A full-stack Chrome extension that seamlessly integrates RateMyProfessors.com ratings into McMaster University’s course enrollment page, providing students with easy access for informed selections

API: https://github.com/sabrahahmed/McMaster-RMP_API
